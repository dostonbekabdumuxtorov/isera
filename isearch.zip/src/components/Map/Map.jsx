import React from 'react'
import './map.css'
const Map = () => {
  return (
    <div>Map</div>
  )
}

export default Map