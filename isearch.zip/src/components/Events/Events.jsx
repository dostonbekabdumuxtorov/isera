import React from 'react'
import './events.css'
const Events = () => {
  return (
    <div>Events</div>
  )
}

export default Events